import { CollectorFactory } from '../scrapper/collectorFactory.js';

export class Crawler {
    /**
     * @param {import('../browsers/browserType.js').BrowserType} browserType
     */
    constructor(browserType) {
        this.browserType = browserType;
        this.collectorFactory = new CollectorFactory();
    }

    /**
     * 크롤링을 실행합니다.
     * @param {Object} body - SQS 메시지 body
     * @returns {Promise<Object>} 크롤링 결과
     */
    async execute(body) {
        const browser = await this.browserType.launch({
            defaultViewport: {
                deviceScaleFactor: 1,
                hasTouch: false,
                height: 1080,
                isLandscape: true,
                isMobile: false,
                width: 1920,
            }
        });
        
        try {
            const collector = this.collectorFactory.createCollector(body.eventType);
            const result = await collector.execute(browser, body.data);
            
            return {
                statusCode: result.statusCode,
                body: JSON.stringify({
                    requestId: body.requestId,
                    ...result.data
                })
            };
        } catch (error) {
            console.error('크롤링 실패:', error);
            return {
                statusCode: 500,
                body: JSON.stringify({
                    requestId: body.requestId,
                    error: error.message
                })
            };
        } finally {
            await browser.close();
        }
    }
} 
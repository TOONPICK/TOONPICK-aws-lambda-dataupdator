// index.cjs - CommonJS to ES Module bridge
module.exports.handler = async (event) => {
    const { handler } = await import('./index.js');
    return handler(event);
};
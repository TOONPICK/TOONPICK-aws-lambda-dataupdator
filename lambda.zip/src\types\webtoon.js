/**
 * @typedef {Object} WebtoonData
 * @property {string} titleId - 네이버 웹툰의 titleId
 */

/**
 * @typedef {Object} WebtoonScrapResult
 * @property {string} title - 웹툰 제목
 */ 